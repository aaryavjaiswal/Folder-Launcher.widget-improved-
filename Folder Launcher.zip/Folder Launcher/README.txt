ABOUT:

This is a project by me for launching your folders on your mac machine.
I hope you like it

HOW TO USE:

In the line;

$(domEl).on 'click', '#iCloud', => @run "open '/Users/your_userid/Library/Mobile\ Documents/com~apple~CloudDocs'"

Replace: /your_userid/ with your finder name like mine is '/Users/aaryavjaiswal/Library/Mobile\' :)

I hope you enjoyed it!!!
